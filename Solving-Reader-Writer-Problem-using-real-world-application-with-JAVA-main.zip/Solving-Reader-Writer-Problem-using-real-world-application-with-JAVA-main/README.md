# Solving-Reader-Writer-Problem-using-real-world-application-with-JAVA (booking cinema tickets )
it includes a solution for the dead lock ,starvation and synchronization problem
